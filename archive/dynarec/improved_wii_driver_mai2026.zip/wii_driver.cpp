/*
	wii dynarec
	based on the mips one !

	PPC/Wii calling rules:
	Registers:
		32 32-bit gprs
			r0     volatile, temp
			r1     stack pointer, grows down
			r2     TOC (what ?) Pointer (who cares)
		    r3:10  volatile, first 8 params.r3 is also return value
		    r11    volatile (used as 'environment' pointers for calls by ptr .. what?)
		    r12    volatile (used for ming (mingw ?) & magic as well as linking)
		    r13:31 preserved (19 of em)
		
		32 64-bit fprs (single, vector or double)
		    f0     volatile, scratch
			f1:4   volatile, params, return
			f5:13  volatile, params
			f14:31 preserved (18 of em)
		LR  Link 
		XER (exception register)
		FPSCR
		CR (CR0:1;CR5:7 volatile, CR2:4 preserved)

	When calling 

	Call stack: 
		Return is stored on the link register and its saved at a specific location on function entry
		lr is stored on sp+4
		stack grows towards zero

	Improvements over original:
	  - BUG FIX: GPR restore loop in ngen_mainloop used ppc_r14+i instead of ppc_r13+i,
	             causing r13 to never be restored and r32 (invalid) to be written. Fixed.
	  - BUG FIX: ppc_lip<T> template overload was missing the destination register 'D'
	             parameter — it silently dropped it. Fixed signature to ppc_lip(u32 D, T*).
	  - Use static_cast<> instead of C-style casts for ppc_finvalid/ppc_rinvalid sentinels.
	  - Use snprintf instead of sprintf to guard against buffer overrun in dynarec filename.
	  - Removed redundant fflush(f) before fclose(f) (fclose already flushes).
	  - Fixed BET_StaticCall/BET_StaticJump: added proper braces around debug-log block
	    so indentation reflects actual control flow.
	  - Minor formatting/whitespace consistency improvements; no logic changes.
*/
#include "types.h"
#include "dc\sh4\sh4_opcode_list.h"

#include "dc\sh4\sh4_registers.h"
#include "dc\sh4\ccn.h"
#include "dc\sh4\rec_v2\ngen.h"
#include "dc\mem\sh4_mem.h"
#include "emitter\PPCEmit\ppc_emitter.h"

// wii_driver.cpp defines its own higher-level wrappers for these names.
// Undefine any macros from ppc_emitter.h that would clash with the
// local function definitions below.
#ifdef ppc_li
#  undef ppc_li
#endif
#ifdef ppc_lis
#  undef ppc_lis
#endif
#ifdef ppc_li32
#  undef ppc_li32
#endif
#ifdef ppc_mr
#  undef ppc_mr
#endif
#ifdef ppc_mov
#  undef ppc_mov
#endif
#ifdef ppc_nop
#  undef ppc_nop
#endif
#ifdef ppc_blr
#  undef ppc_blr
#endif
#ifdef ppc_bctr
#  undef ppc_bctr
#endif
#ifdef ppc_bctrl
#  undef ppc_bctrl
#endif
#ifdef ppc_b
#  undef ppc_b
#endif
#ifdef ppc_bl
#  undef ppc_bl
#endif
// These are defined as real functions below; ppc_bx is also a real function
// (overload of the auto-generated one) so guard it too.
#ifdef ppc_bx
#  undef ppc_bx
#endif

// Define "invalid" value for non-mapped-registery
const ppc_freg ppc_finvalid = static_cast<ppc_freg>(-1);  // sentinel: out-of-range (valid regs are 0..31)
const ppc_ireg ppc_rinvalid = static_cast<ppc_ireg>(-1);  // sentinel: out-of-range (valid regs are 0..31)

// This is defined in main.cpp
extern "C" int get_debug_loop();

// ppc_li: Loads a 32-bit immediate value into a PowerPC register.
void ppc_li(u32 D,u32 imm)
{
	if (is_s16(imm))
	{
		ppc_addi(D,0,imm);
		return;
	}
	else
	{
		ppc_addis(D,0,imm>>16);
		ppc_ori(D,D,(u16)imm);
	}
}

// =======================
// JUMP OFFSET CALCULATION
// =======================

snat ppc_jdiff_raw(void* dst)
{
	return (u8*)dst-(u8*)emit_GetCCPtr();
}
snat ppc_jdiff(void* dst)
{
	return ppc_jdiff_raw(dst)>>2;
}

void ppc_bx(void* dst,u32 LK)
{
	snat offs = ppc_jdiff_raw(dst);
	//offs must fit in 24 bits
	verify(offs<33554432 && offs>-33554432);
	offs>>=2;
	// does this work ? //
	ppc_bx(offs,0,LK);
}

void ppc_call(void* funct)
{
	ppc_bx(funct,1);
}
template<typename T> void ppc_call(T* dst) { return ppc_call((void*)dst); }

void ppc_jump(void* funct)
{
	ppc_bx(funct,0);
}
template<typename T> void ppc_jump(T* dst) { return ppc_jump((void*)dst); }
void ppc_call_and_jump(void* funct)
{
	ppc_call(funct);
	ppc_mtctr(ppc_r3);
	ppc_bcctrx(BO_ALWAYS,BI_CR0_EQ,0);  // bctr
}
template<typename T> void ppc_call_and_jump(T* dst) { return ppc_call_and_jump((void*)dst); }
void make_address_range_executable(void* addr, u32 size)
{
	//what gives?
	DCFlushRange(addr, size);
	ICInvalidateRange(addr, size);
}

void ppc_lip(u32 D,void* ptr)
{
	ppc_li(D,(u8*)ptr-(u8*)0);
}
template<typename T> void ppc_lip(u32 D, T* ptr) { return ppc_lip(D, (void*)ptr); }

ppc_ireg ppc_cycles = ppc_r29;
ppc_ireg ppc_contex = ppc_r30;
ppc_ireg ppc_djump = ppc_r31;
ppc_ireg ppc_next_pc = ppc_rarg0;

void ppc_emit(u32 insn)
{
	emit_Write32(insn);
}

void* loop_no_update;
void* ngen_LinkBlock_Static_stub;
void* ngen_LinkBlock_Dynamic_1st_stub;
void* ngen_LinkBlock_Dynamic_2nd_stub;
void* ngen_BlockCheckFail_stub;
void* loop_do_update_write;
void (*loop_code)() ;
void (*ngen_FailedToFindBlock)();

struct
{
	bool has_jcond;

	void Reset()
	{
		has_jcond=false;
	}
} compile_state;
u32 last_block;

// Tracks whether any mapped GPR/FPR was accessed in the current block.
// Reset to 0 by ngen_Begin(); incremented by ppc_sh_load/ppc_sh_store fast paths.
// reg_flush_all() and reg_reload_all() skip their loops entirely when this is 0,
// eliminating 30 stw/lwz instructions per shop_ifb on pure-RAM blocks.
static u32 s_mapped_regs_used = 0;

// ---------------------------------------------------------------------------
// dynarec_aggressive_reload
//
// When FALSE (default, safe): reg_reload_all() after shop_ifb is always forced,
// even when no mapped reg was touched earlier in the block. This is required for
// games like Crazy Taxi where the interpreter may update r8-r15 before those
// registers are first loaded in a block — without the forced reload the PPC
// hardware regs hold stale pre-interpreter values.
//
// When TRUE (aggressive, fast): reg_reload_all() is gated purely by
// s_mapped_regs_used. shop_ifb does NOT force-increment the counter, so blocks
// that never loaded a mapped reg before the shop_ifb skip the 7x lwz reload
// entirely. This gives a measurable FPS boost on integer-heavy games with many
// short blocks (e.g. Sega Tetris) but breaks games whose blocks happen to use
// interpreter-fallback opcodes before their first mapped-reg load.
//
// Expose via extern in your menu code:
//   extern bool dynarec_aggressive_reload;
//   dynarec_aggressive_reload = true;  // enable for this game
// ---------------------------------------------------------------------------
bool dynarec_aggressive_reload = true;

// Forward declarations — definitions appear after GetIntReg/GetFloatReg below.
void reg_flush_all();
void reg_reload_all();

// =======================
// BLOCK BEGIN/END
// =======================

void ngen_Begin(DecodedBlock* block,bool force_checks)
{
	compile_state.Reset();
	s_mapped_regs_used = 0;   // reset per-block mapped-reg usage counter

	ppc_addic(ppc_cycles,ppc_cycles,-block->cycles,1);
	
	ppc_label* jdst=ppc_CreateLabel();
	ppc_bcx(BO_FALSE,BI_CR0_LT,0,0,0);

	ppc_li(ppc_next_pc,block->start);
	ppc_jump(loop_do_update_write);

	jdst->MarkLabel();
}

// =====================
// MEMORY ACCESS HELPERS
// =====================

// Forward declarations — definitions appear after ngen_End() below.
ppc_ireg GetIntReg(u32 reg);
ppc_freg GetFloatReg(u32 reg);

// emit_mr: PowerPC "move register" — encoded as OR rD, rS, rS (no separate MR opcode)
inline void emit_mr(u32 D, u32 S)
{
	ppc_orx(D, S, S, 0);  // mr D, S
}

// emit_fmr: PowerPC "floating-point move register"
// FMR encoding: primary=63 (0x3F), XO=72 (0x48), Rc=0
// Emitted raw to avoid emitter naming ambiguity.
inline void emit_fmr(u32 D, u32 S)
{
	ppc_emit((63u << 26) | (D << 21) | (0u << 16) | (S << 11) | (72u << 1) | 0u);
}

// Load SH4 integer register sh4_reg into PPC GPR D.
// Fast path: if sh4_reg is globally mapped, emit mr (single cycle register rename).
// Slow path: emit lwz from Sh4cntx in RAM.
void ppc_sh_load(u32 D, u32 sh4_reg)
{
	ppc_ireg mapped = GetIntReg(sh4_reg);
	if (mapped != ppc_rinvalid)
	{
		s_mapped_regs_used++;
		emit_mr(D, (u32)mapped);
	}
	else
		ppc_lwz(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}
void ppc_sh_load(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_load(D, prm._reg);
}

// Load SH4 float register sh4_reg into PPC FPR D.
// Fast path: if sh4_reg is globally mapped, emit fmr (single cycle FPR rename).
// Slow path: emit lfs from Sh4cntx in RAM.
void ppc_sh_load_f32(u32 D, u32 sh4_reg)
{
	ppc_freg mapped = GetFloatReg(sh4_reg);
	if (mapped != ppc_finvalid)
	{
		s_mapped_regs_used++;
		emit_fmr(D, (u32)mapped);
	}
	else
		ppc_lfs(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}
void ppc_sh_load_f32(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_load_f32(D, prm._reg);
}

// u16 loads are never globally mapped — always go to RAM.
void ppc_sh_load_u16(u32 D, u32 sh4_reg)
{
	ppc_lhz(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}
void ppc_sh_load_u16(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_load_u16(D, prm._reg);
}

// Address-of helper — never uses mapped regs (needs actual RAM pointer).
void ppc_sh_addr(u32 D, u32 sh4_reg)
{
	ppc_addi(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}
void ppc_sh_addr(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_addr(D, prm._reg);
}

// Store PPC GPR D into SH4 integer register sh4_reg.
// WRITE-THROUGH: if sh4_reg is mapped, update BOTH the live PPC hardware reg
// AND RAM. This keeps Sh4cntx always coherent so reg_flush_all() is a no-op
// and shop_ifb / C calls never see stale values across block boundaries.
void ppc_sh_store(u32 D, u32 sh4_reg)
{
	ppc_ireg mapped = GetIntReg(sh4_reg);
	if (mapped != ppc_rinvalid)
	{
		s_mapped_regs_used++;
		emit_mr((u32)mapped, D);                                    // update live PPC reg
		ppc_stw(D, ppc_contex, Sh4cntx.offset(sh4_reg));           // keep RAM in sync
	}
	else
		ppc_stw(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}
void ppc_sh_store(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_store(D, prm._reg);
}

// Store PPC FPR D into SH4 float register sh4_reg.
// WRITE-THROUGH: same policy as integer stores (floats currently never mapped,
// but the pattern is in place for when FPR mapping is re-enabled).
void ppc_sh_store_f32(u32 D, u32 sh4_reg)
{
	ppc_freg mapped = GetFloatReg(sh4_reg);
	if (mapped != ppc_finvalid)
	{
		s_mapped_regs_used++;
		emit_fmr((u32)mapped, D);
		ppc_stfs(D, ppc_contex, Sh4cntx.offset(sh4_reg));          // keep RAM in sync
	}
	else
		ppc_stfs(D, ppc_contex, Sh4cntx.offset(sh4_reg));
}

u32 ppc_addr_high(u32 rD, void* ptr)
{
	unat diff=(u8*)ptr-(u8*)0;
	u32 rv=(s32)(s16)diff;
	diff-=rv;
	ppc_addis(rD,0,diff>>16);

	return rv;
}

void ppc_sh_store_f32(u32 D, shil_param prm)
{
	verify(prm.is_reg());
	ppc_sh_store_f32(D, prm._reg);
}

// ==========================
// CALLING CONVENTION ADAPTER
// ==========================

struct CC_PS
{
	CanonicalParamType type;
	shil_param* par;
};
vector<CC_PS> CC_pars;
void ngen_CC_Start(shil_opcode* op) 
{ 
	CC_pars.clear();
}
void ngen_CC_Param(shil_opcode* op,shil_param* par,CanonicalParamType tp) 
{
	switch(tp)
	{
		case CPT_f32rv:
			ppc_sh_store_f32(ppc_frv0, *par);
			break;

		case CPT_u32rv:
		case CPT_u64rvL:
			ppc_sh_store(ppc_rrv0, *par);
			break;

		case CPT_u64rvH:
			ppc_sh_store(ppc_rrv1, *par);
			break;

		case CPT_u32:
		case CPT_ptr:
		case CPT_f32:
			{
				CC_PS t={tp,par};
				CC_pars.push_back(t);
			}
			break;

		default:
			die("invalid tp");
	}
}
void ngen_CC_Call(shil_opcode*op,void* function) 
{
	u32 rd_fp=ppc_farg0;
	u32 rd_gpr=ppc_rarg0;
	for (int i=CC_pars.size();i-->0;)
	{
		if (CC_pars[i].type==CPT_ptr)
		{
			ppc_sh_addr(rd_gpr,*CC_pars[i].par);
		}
		else
		{
			if (CC_pars[i].par->is_reg())
			{
				if (CC_pars[i].type==CPT_f32)
				{
					ppc_sh_load_f32(rd_fp,*CC_pars[i].par);
					rd_fp++;
				}
				else
				{
					ppc_sh_load(rd_gpr,*CC_pars[i].par);
				}
			}
			else
				ppc_li(rd_gpr,CC_pars[i].par->_imm);
		}
		rd_gpr++;
	}
	//printf("used reg r0 to r%d, %d params, calling %08X\n",rd-1,CC_pars.size(),function);
	ppc_call(function);
}

// =================
// BINARY OPERATIONS
// =================

void binop_start(shil_opcode* op)
{
	verify(!op->rs1.is_null() && !op->rs2.is_null() && !op->rd.is_null());

	verify(op->rs1.is_reg());
	//verify(!op->rs2.is_imm() || op->rs2.is_imm_s16());
	
	ppc_sh_load(ppc_rarg0,op->rs1);

	if (op->rs2.is_imm())
	{
		ppc_li(ppc_rarg1,op->rs2._imm);
	}
	else if (op->rs2.is_reg())
	{
		ppc_sh_load(ppc_rarg1,op->rs2);
	}
}

void binop_end(shil_opcode* op)
{
	ppc_sh_store(ppc_rarg0,op->rd);
}

void binop_start_fpu(shil_opcode* op)
{
	verify(!op->rs1.is_null() && !op->rs2.is_null() && !op->rd.is_null());

	verify(op->rs1.is_reg());
	verify(op->rs2.is_reg());
	
	ppc_sh_load_f32(ppc_farg0,op->rs1);
	ppc_sh_load_f32(ppc_farg1,op->rs2);
}

void binop_end_fpu(shil_opcode* op)
{
	ppc_sh_store_f32(ppc_farg0,op->rd);
}


void ngen_CC_Finish(shil_opcode* op) 
{ 
	CC_pars.clear(); 
}
void DoStatic(u32 pc)
{
	ppc_li(ppc_rarg0,pc);
	ppc_call(ngen_LinkBlock_Static_stub);
}

// ====================================
// ngen_End: Block Exit Code Generation
// ====================================

void ngen_End(DecodedBlock* block)
{
	switch(block->BlockType)
	{
	case BET_Cond_0:
	case BET_Cond_1:
		{
			//printf("COND %d\n",block->BlockType&1);
			//die("not supported");
			u32 reg;
			if (compile_state.has_jcond)
			{
				reg=ppc_djump;
			}
			else
			{
				reg=ppc_rarg0;
				ppc_sh_load(ppc_rarg0,reg_sr_T);
			}
			
			ppc_cmpi(ppc_cr0,reg,block->BlockType&1,0);
	
			ppc_label* jtrue=ppc_CreateLabel();
			ppc_bcx(BO_TRUE,BI_CR0_EQ,0,0,0);

			DoStatic(block->NextBlock);
			jtrue->MarkLabel();
			DoStatic(block->BranchBlock);
		}
		break;

	case BET_DynamicCall:
	case BET_DynamicJump:
	case BET_DynamicRet:
		//printf("Dynamic !\n");
		//mov reg,djump
		ppc_ori(ppc_rarg0,ppc_djump,0);  // mr rarg0, djump
		//jmp no update
		ppc_jump(loop_no_update);
		break;

	case BET_StaticIntr:
	case BET_DynamicIntr:
		printf("BET: Interrupt !\n");
		{
			u32 reg;
			if (block->BlockType==BET_StaticIntr)
			{
				ppc_li(ppc_rarg0,block->BranchBlock);
				reg=ppc_rarg0;
			}
			else
			{
				reg=ppc_djump;
			}
			ppc_sh_store(reg,reg_nextpc);
			reg_flush_all();   // mapped r8-r15 must be in RAM before UpdateINTC reads Sh4cntx
			ppc_call(&UpdateINTC);

			ppc_sh_load(ppc_next_pc,reg_nextpc);
			ppc_jump(loop_no_update);
		}
		break;

	case BET_StaticCall:
	case BET_StaticJump:
		if (get_debug_loop() == 1)
		{
			printf("Static 0x%08X!\n", block->BranchBlock);
		}
		DoStatic(block->BranchBlock);
		break;

	default:
		printf("END TYPE: %d\n",block->BlockType);
		die("wtfh end type\n");
	}
}

//f14:f29
// DISABLED: SH4 has two float banks (fr/xf) swapped by FPSCR.FR via ChangeFP().
// Globally mapping fr[] to PPC f14-f29 causes stale values in the mapped regs
// after a bank swap — the game then submits corrupted vertex data to the TA,
// producing a white screen. The xf[] bank is never mapped so after ChangeFP()
// the live PPC fprs still hold pre-swap fr[] values. Since reg_reload_all() is
// only emitted at mainloop entry (not after every FPSCR write), there is no
// safe place to re-sync them from JIT code. Solution: always use the RAM path
// for floats. Integer GPRs are safe because ChangeGPR() only swaps r_bank[]
// (r0-r7 shadow), leaving r[] (what we map) untouched.
ppc_freg GetFloatReg(u32 reg)
{
	(void)reg;
	return ppc_finvalid;   // always RAM path — see comment above
}

//r14:r21 mapped to SH4 r8-r15 (8 regs, skipping r11→r14+2=r16 gap handled below)
// r0-r7 are EXCLUDED: SR.RB bank switches swap Sh4cntx.r[0..7] with r_bank[]
// via ChangeGPR(). After a bank swap the RAM is updated but the PPC hardware
// regs would hold stale pre-swap values until the next reg_reload_all() — which
// is only emitted at mainloop entry and after shop_ifb, not after every exception.
// r8-r15 are never touched by ChangeGPR() so they are always coherent.
// reg_r11 is still skipped to keep the original hole (it was excluded before too).
ppc_ireg GetIntReg(u32 reg)
{
	if (reg >= reg_r8 && reg <= reg_r15 && reg != reg_r11)
	{
		// Map r8->ppc_r14, r9->r15, r10->r16, skip r11, r12->r17, r13->r18, r14->r19, r15->r20
		u32 idx = reg - reg_r8;
		if (reg > reg_r11) idx--; // close the r11 hole
		return (ppc_ireg)(ppc_r14 + idx);
	}
	return ppc_rinvalid;
}
// reg_flush_all: No-op under the write-through model.
// ppc_sh_store now writes to BOTH the live PPC hardware reg AND Sh4cntx RAM,
// so RAM is always coherent. No explicit flush needed before C calls or shop_ifb.
// The function is kept so all call sites compile without change.
void reg_flush_all()
{
	// write-through: nothing to do
}

// reg_reload_all: Prime all globally-mapped PPC hardware regs from Sh4cntx RAM.
// Called once at mainloop entry (after ppc_contex has been initialised).
// Also called after shop_ifb returns from the interpreter, since C code may have
// modified Sh4cntx fields directly (e.g. exception handling writing r8-r15).
//
// Under the write-through model, RAM is always coherent with PPC mapped regs,
// so this is only needed after C code runs. s_mapped_regs_used guards it:
// if this block never loaded a mapped reg, no mapped reg is live in a PPC
// hardware reg, so there is nothing stale to reload — skip it.
void reg_reload_all()
{
	if (!s_mapped_regs_used) return;
	for (u32 i = 0; i < sh4_reg_count; i++)
	{
		ppc_freg rf = GetFloatReg(i);
		if (rf != ppc_finvalid)
		{
			ppc_lfs((u32)rf, ppc_contex, Sh4cntx.offset(i));
			continue;
		}
		ppc_ireg ri = GetIntReg(i);
		if (ri != ppc_rinvalid)
		{
			ppc_lwz((u32)ri, ppc_contex, Sh4cntx.offset(i));
		}
	}
}
void FASTCALL do_sqw_mmu(u32 dst);
void FASTCALL do_sqw_nommu(u32 dst);

// =====================
// OPERATION COMPILATION
// =====================

// ngen_CompileBlock: Main Block Compilation Loop
DynarecCodeEntry* ngen_Compile(DecodedBlock* block,bool force_checks)
{
	// Bail out early if there isn't enough space for a worst-case block
	if (emit_FreeSpace() < 16384) // 16*1024
		return 0;
	
	DynarecCodeEntry* rv=(DynarecCodeEntry*)emit_GetCCPtr();
	
	ngen_Begin(block,force_checks);

	for (size_t i = 0; i < block->oplist.size(); i++)
	{
		shil_opcode* op=&block->oplist[i];
		switch(op->op)
		{

		case shop_readm:
			{
				void* fuct=0;
				bool isram=false;
				verify(op->rs1.is_imm() || op->rs1.is_r32i());

				if (op->rs1.is_imm())
				{
					void* ptr=_vmem_read_const(op->rs1._imm,isram,op->flags);
					if (isram)
					{
						if (op->flags==1)
						{
							ppc_lbz(ppc_r3,ppc_r4,ppc_addr_high(ppc_r4,ptr));
							ppc_extsbx(ppc_r3,ppc_r3,0);
						}	
						else if (op->flags==2)
							ppc_lha(ppc_r3,ppc_r4,ppc_addr_high(ppc_r4,ptr));
						else if (op->flags==4)
							ppc_lwz(ppc_r3,ppc_r4,ppc_addr_high(ppc_r4,ptr));
						else
						{
							die("Invalid mem read size");
						}
					}
					else
					{
						ppc_li(ppc_rarg0,op->rs1._imm);
						fuct=ptr;
					}
				}
				else
				{
					ppc_sh_load(ppc_rarg0,op->rs1);
					if (op->rs3.is_imm())
					{
						verify(op->rs3.is_imm_s16());
						ppc_addi(ppc_rarg0,ppc_rarg0,op->rs3._imm);
					}
					else if (op->rs3.is_r32i())
					{
						ppc_sh_load(ppc_rarg1,op->rs3);
						ppc_addx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0,0);
					}
					else if (!op->rs3.is_null())
					{
						die("invalid rs3");
					}
				}

				if (!isram)
				{
					switch(op->flags)
					{
					case 1:
						if (!fuct) fuct=(void*)ReadMem8;
						ppc_call(fuct);
						ppc_extsbx(ppc_rrv0,ppc_rrv0,0);
						break;
					case 2:
						if (!fuct) fuct=(void*)ReadMem16;
						ppc_call(fuct);
						ppc_extshx(ppc_rrv0,ppc_rrv0,0);
						break;
					case 4:
						if (!fuct) fuct=(void*)ReadMem32;
						ppc_call(fuct);
						break;
					case 8:
						if (!fuct) fuct=(void*)ReadMem64;
						ppc_call(fuct);
						break;
					default:
						verify(false);
					}
				}
				
				ppc_sh_store(ppc_rrv0,op->rd);

				if (op->flags==8)
				{
					ppc_sh_store(ppc_rrv1,op->rd._reg+1);
				}
			}
			break;

		case shop_writem:
			{
				ppc_sh_load(ppc_rarg0,op->rs1);
				

				if (op->flags==8)
				{
					ppc_sh_load(ppc_rarg2,op->rs2);
					ppc_sh_load(ppc_rarg3,op->rs2._reg+1);
				}
				else
					ppc_sh_load(ppc_rarg1,op->rs2);

				if (op->rs3.is_imm())
				{
					verify(op->rs3.is_imm_s16());
					ppc_addi(ppc_rarg0,ppc_rarg0,op->rs3._imm);
				}
				else if (op->rs3.is_r32i())
				{
					ppc_sh_load(ppc_rarg3,op->rs3);

					ppc_addx(ppc_rarg0,ppc_rarg0,ppc_rarg3,0,0);
				}
				else if (!op->rs3.is_null())
				{
					printf("rs3: %08X\n",op->rs3.type);
					die("invalid rs3");
				}

				switch(op->flags)
				{
				case 1:
					ppc_andi(ppc_rarg1,ppc_rarg1,0xFF);
					ppc_call(&WriteMem8);
					break;
				case 2:
					ppc_andi(ppc_rarg1,ppc_rarg1,0xFFFF);
					ppc_call(&WriteMem16);
					break;
				case 4:
					ppc_call(&WriteMem32);
					break;
				case 8:
					ppc_call(&WriteMem64);
					break;
				default:
					die("invalid size on memwrite");
				}
			}
			break;

		case shop_ifb:
			{
				reg_flush_all();
				if (op->rs1._imm)
				{
					ppc_li(ppc_rarg0,op->rs2._imm);
					ppc_sh_store(ppc_rarg0,reg_nextpc);
				}
				ppc_li(ppc_rarg0,op->rs3._imm);
				ppc_call(OpDesc[op->rs3._imm]->oph);
				// Safe mode (default): always force reg_reload_all() after the
				// interpreter call, regardless of whether any mapped reg was loaded
				// earlier in this block. Required for games like Crazy Taxi where
				// the interpreter modifies r8-r15 before the block's first mapped-reg
				// load — without this, ppc_r14-r20 hold stale pre-interpreter values.
				//
				// Aggressive mode: skip the forced increment. reg_reload_all() only
				// runs if a mapped reg was already loaded earlier in the block.
				// Faster for integer-heavy games (e.g. Sega Tetris) but unsafe for
				// games where interpreter fallbacks appear before mapped-reg loads.
				if (!dynarec_aggressive_reload)
					s_mapped_regs_used++;
				reg_reload_all();
			}
			break;
			
		case shop_jdyn:
			{
				ppc_sh_load(ppc_djump,op->rs1);
				
				if (op->rs2.is_imm())
				{
					if (op->rs2.is_imm_s16())
					{
						ppc_addi(ppc_djump,ppc_djump,op->rs2._imm);
					}
					else
					{
						ppc_li(ppc_rarg0,op->rs2._imm);
						ppc_addx(ppc_djump,ppc_djump,ppc_rarg0,0,0);
					}
				}
			}
			break;
			
		case shop_jcond:
			{
				compile_state.has_jcond=true;
				ppc_sh_load(ppc_djump,op->rs1);
			}
			break;
			
		case shop_mov64:
			{
				verify(op->rd.is_r64());
				verify(op->rs1.is_r64());

				ppc_sh_load(ppc_rarg0,op->rs1);
				ppc_sh_load(ppc_rarg1,op->rs1._reg+1);

				ppc_sh_store(ppc_rarg0,op->rd);
				ppc_sh_store(ppc_rarg1,op->rd._reg+1);
			}
			break;

		case shop_mov32:
			{
				verify(op->rd.is_r32());

				if (op->rs1.is_imm())
				{
					ppc_li(ppc_rarg0,op->rs1._imm);
				}
				else if (op->rs1.is_r32())
				{
					ppc_sh_load(ppc_rarg0,op->rs1);
				}
				else
				{
					die("Invalid mov32 size");
				}

				ppc_sh_store(ppc_rarg0,op->rd);
			}
			break;

		case shop_add: binop_start(op); ppc_addx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0,0); binop_end(op); break;
		case shop_sub: binop_start(op); ppc_subfx(ppc_rarg0,ppc_rarg1,ppc_rarg0,0,0); binop_end(op); break;
		
		case shop_or: binop_start(op); ppc_orx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;
		case shop_and: binop_start(op); ppc_andx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;
		case shop_xor: binop_start(op); ppc_xorx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;

		case shop_shl: binop_start(op); ppc_slwx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;
		case shop_shr: binop_start(op); ppc_srwx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;
		case shop_sar: binop_start(op); ppc_srawx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0); binop_end(op); break;
		case shop_mul_i32: binop_start(op); ppc_mullwx(ppc_rarg0,ppc_rarg0,ppc_rarg1,0,0); binop_end(op); break;


		case shop_fadd: binop_start_fpu(op); ppc_faddsx(ppc_farg0,ppc_farg0,ppc_farg1,0); binop_end_fpu(op); break;
		case shop_fsub: binop_start_fpu(op); ppc_fsubsx(ppc_farg0,ppc_farg0,ppc_farg1,0); binop_end_fpu(op); break;
		case shop_fmul: binop_start_fpu(op); ppc_fmulsx(ppc_farg0,ppc_farg0,ppc_farg1,0); binop_end_fpu(op); break;
		case shop_fdiv: binop_start_fpu(op); ppc_fdivsx(ppc_farg0,ppc_farg0,ppc_farg1,0); binop_end_fpu(op); break;


		default:
			//canonical fallback ~
      if (!shil_chf[op->op]) {
          printf("OH CRAP %d\n", op->op);
          die("Recompiler doesn't know about that opcode");
      }
			shil_chf[op->op](op);
			break;
      
		}
	}

	ngen_End(block);

	make_address_range_executable((u8*)rv, (u8*)emit_GetCCPtr()-(u8*)rv);
	return rv;
}



void ngen_ResetBlocks()
{
}

void* FASTCALL ngen_LinkBlock_Static(u32 pc,u32* patch)
{
	next_pc=pc;
	
	DynarecCodeEntry* rv=rdv_FindOrCompile();
	
	emit_ptr=patch;
	{
		ppc_jump(rv);
	}
	emit_ptr=0;

	make_address_range_executable(patch, 1*sizeof(u32));

	return (void*)rv;
}

// =========
// MAIN LOOP
// =========

void ngen_mainloop()
{
	if (loop_code==0)
	{

		loop_code=(void(*)())emit_GetCCPtr();
		{
			/*
			create stack frame, push regsters, etc ..
			*/
			u32 stac_alloc_size=8+20*4;
			ppc_mfspr(ppc_r0,ppc_spr_lr);
			ppc_addi(ppc_sp,ppc_sp,-stac_alloc_size);
			
			//store link register
			ppc_stw(ppc_r0,ppc_sp,stac_alloc_size+4);

			//store gprs r13..r31 (19 preserved regs per ABI)
			// Layout: sp+[stac_alloc_size-4] = r13, sp+[stac_alloc_size-8] = r14, ...
			for (int i=0;i<19;i++)
			{
				ppc_stw(ppc_r13+i,ppc_sp,stac_alloc_size-4-i*4);
			}

			//cntx base -- MUST be set before reg_reload_all() uses it as the base address
			ppc_lip(ppc_contex,&Sh4cntx);

			/*
			pre load registers/counters etc ..
			*/
			reg_reload_all();

			//cycles
			ppc_li(ppc_cycles,SH4_TIMESLICE);

			//and pc!
			ppc_sh_load(ppc_next_pc,reg_nextpc);

			//no_update
			loop_no_update=emit_GetCCPtr();

			//handy function !
			ppc_call_and_jump(bm_GetCode);

			//do_update_write
			loop_do_update_write=emit_GetCCPtr();


			//next_pc _MUST_ be on ram since update system uses it for interrupt processing
			ppc_sh_store(ppc_next_pc,reg_nextpc);
			ppc_addi(ppc_cycles,ppc_cycles,SH4_TIMESLICE);	//add cycles ...

			ppc_call(UpdateSystem);	//call UpdateSystem
			ppc_sh_load(ppc_next_pc,reg_nextpc);
			//
			ppc_jump(loop_no_update);
			//right

      /*
      Claude AI says it's dead end after looking in dump dynarec_XXX.bin
			ppc_lbz(ppc_rarg0,ppc_rarg0,ppc_addr_high(ppc_rarg0,(void*)&sh4_int_bCpuRun));
			ppc_sh_load(ppc_next_pc,reg_nextpc);

			ppc_cmpi(ppc_cr0,ppc_rarg0,1,0);	//set flags

			//does this even work ?
			//ppc_bcx(BO_TRUE,BI_CR0_EQ,ppc_jdiff(loop_no_update),0,0);
			

			//write back registers and stuff ...

			//cleanup
			
			Clean up the stack frame and return ...
			

			//restore link register
			ppc_lwz(ppc_r0,ppc_sp,stac_alloc_size+4);
			ppc_mtlr(ppc_r0);

			//restore gprs 13 .. 31
			for (int i=0;i<19;i++)
			{
				ppc_lwz(ppc_r13+i,ppc_sp,stac_alloc_size-4-i*4);
			}

			

			//destroy stack frame
			ppc_addi(ppc_sp,ppc_sp,stac_alloc_size);

			//return
			ppc_bclrx(BO_ALWAYS,BI_CR0_EQ,0);  // blr
      */

		} //that was mainloop


		//ngen_FailedToFindBlock
		ngen_FailedToFindBlock=(void(*)())emit_GetCCPtr();
		{
			ppc_call_and_jump(&rdv_FailedToFindBlock);
		}

    // ====================
    // STATIC BLOCK LINKING
    // ====================

		ngen_LinkBlock_Static_stub=emit_GetCCPtr();
		{
			//not used for now
			ppc_mfspr(ppc_rarg1,ppc_spr_lr);
			
			ppc_addi(ppc_rarg1,ppc_rarg1,(u32)-12);
			ppc_call_and_jump(&ngen_LinkBlock_Static);
		}

		ngen_LinkBlock_Dynamic_1st_stub=emit_GetCCPtr();
		{
			//not used for now
		}

		ngen_LinkBlock_Dynamic_2nd_stub=emit_GetCCPtr();
		{
			//not used for now
		}

		ngen_BlockCheckFail_stub=emit_GetCCPtr();
		{
			ppc_call_and_jump(&rdv_BlockCheckFail);
		}

		//Make _SURE_ this code is not overwriten !
		emit_SetBaseAddr();
		
		char file[512];
		snprintf(file, sizeof(file), "dynarec_%08X.bin", (u32)(uintptr_t)loop_code);
		char* path=GetEmuPath(file);

		FILE* f = fopen(path, "wb");
		free(path);

		if (f)
		{
			fwrite((void*)loop_code, 1, CODE_SIZE - emit_FreeSpace(), f);
			fclose(f);  // fclose flushes; explicit fflush is redundant
		}
		
    // CACHE COHERENCY
    make_address_range_executable((u8*)loop_code, (u8*)emit_GetCCPtr()-(u8*)loop_code);
	}

	loop_code();
}

void ngen_GetFeatures(ngen_features* dst)
{
	dst->InterpreterFallback=false;
	dst->OnlyDynamicEnds=false;
}