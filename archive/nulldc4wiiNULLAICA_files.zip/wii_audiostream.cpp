// wii_audiostream.cpp
//
// Audio backend for the Wii port of nullAICA.
// Adapted from xenon_audiostream.cpp:
//   - Same 44100->48000 Hz linear resampler
//   - Same accumulate-then-submit pattern
//   - Samples byte-swapped for big-endian hardware
//   - xenon_sound_submit replaced with AESND / wii_audio calls
//
// The Wii audio hardware runs at 48000 Hz, stereo 16-bit.
// AICA generates samples at 44100 Hz so we resample in batches.

#include "wii_audiostream.h"
#include "wii/wii_audio.h"    // wii_audio_submit(s16* buf, u32 samples)

// Batch size: 441 samples at 44100 Hz = 10 ms per submit (same as Xenon)
#define SAMPLE_RATE_IN   44100
#define SAMPLE_RATE_OUT  48000
#define BATCH_IN         441
#define BATCH_OUT        ((BATCH_IN * SAMPLE_RATE_OUT + SAMPLE_RATE_IN - 1) / SAMPLE_RATE_IN)  // 480
#define BUFFER_SIZE      65536

static s16 buf_in[BUFFER_SIZE];    // accumulated 44100 Hz samples (interleaved L/R)
static s16 buf_out[BUFFER_SIZE];   // resampled 48000 Hz samples
static int buf_pos = 0;

static s16 prev_last[2] = {0, 0};  // last sample of previous batch (for interpolation)

// Linear resampler — identical to Xenon port, pure math, no platform deps.
static void ResampleLinear(s16* src, s32 src_count, s16* dst, s32 dst_count)
{
    for (s32 i = 0; i < dst_count; ++i)
    {
        s32 io  = i * src_count;
        s32 old = io / dst_count;
        s32 rem = io - old * dst_count;
        old *= 2; // stereo

        s32 nL, nR;
        if (old == 0)
        {
            nL = prev_last[0] * (dst_count - rem) + src[0] * rem;
            nR = prev_last[1] * (dst_count - rem) + src[1] * rem;
        }
        else
        {
            nL = src[old - 2] * (dst_count - rem) + src[old]     * rem;
            nR = src[old - 1] * (dst_count - rem) + src[old + 1] * rem;
        }
        dst[2 * i]     = (s16)(nL / dst_count);
        dst[2 * i + 1] = (s16)(nR / dst_count);
    }
    prev_last[0] = src[src_count * 2 - 2];
    prev_last[1] = src[src_count * 2 - 1];
}

void wii_InitAudio()
{
    buf_pos      = 0;
    prev_last[0] = 0;
    prev_last[1] = 0;
    // wii_audio_init() is called by the main Wii startup code before plugins load.
    // Nothing extra needed here.
}

void wii_TermAudio()
{
    // Nothing to release — Wii audio is managed globally.
}

// Called by AICA_Sample() once per 44100 Hz sample.
void wii_WriteSample(s16 r, s16 l)
{
    buf_in[buf_pos++] = r;
    buf_in[buf_pos++] = l;

    if (buf_pos >= BATCH_IN * 2)
    {
        // Resample 441 -> 480 samples
        ResampleLinear(buf_in, BATCH_IN, buf_out, BATCH_OUT);

        // Byte-swap for big-endian Wii hardware
        for (int i = 0; i < BATCH_OUT * 2; ++i)
        {
            s16 v = buf_out[i];
            buf_out[i] = (s16)(((v & 0xFF) << 8) | ((v >> 8) & 0xFF));
        }

        // Submit to Wii audio hardware
        wii_audio_submit(buf_out, BATCH_OUT);

        buf_pos = 0;
    }
}
