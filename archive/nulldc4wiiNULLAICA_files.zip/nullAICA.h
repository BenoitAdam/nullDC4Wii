#pragma once
#include "nullDC/types.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

// Wii is big-endian PowerPC — same as Xenon
#define WII 1

// Byte-swap macros for big-endian (from Xenon port)
#define ReadMemArrRet(arr,addr,sz)               \
    {if (sz==1)                                  \
        return arr[(addr)^3];                    \
    else if (sz==2)                              \
        return (*(u16*)&arr[(addr)^2]);          \
    else if (sz==4)                              \
        return (*(u32*)&arr[(addr)]);}

#define WriteMemArrRet(arr,addr,data,sz)         \
    {if(sz==1)                                   \
        {arr[(addr)^3]=(u8)data;return;}         \
    else if (sz==2)                              \
        {*(u16*)&arr[(addr)^2]=((u16)data);return;} \
    else if (sz==4)                              \
    {*(u32*)&arr[(addr)]=(data);return;}}

#define WriteMemArr(arr,addr,data,sz)            \
    {if(sz==1)                                   \
        {arr[(addr)^3]=(u8)data;}                \
    else if (sz==2)                              \
        {*(u16*)&arr[(addr)^2]=((u16)data);}     \
    else if (sz==4)                              \
    {*(u32*)&arr[(addr)]=(data);}}

#define UINT16 u16
#define INT32  s32
#define DWORD  u32
#define UINT32 u32

#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))

#define DCclock (200*1000*1000)

struct aica_setts
{
    u32 SoundRenderer;   // 0 -> SDL, 1 -> Wii audio
    u32 HW_mixing;       // unused on Wii
    u32 BufferSize;      // in samples
    u32 LimitFPS;        // 0 -> no, 1 -> limit
    u32 GlobalFocus;     // unused on Wii
    u32 BufferCount;
    u32 CDDAMute;
    u32 GlobalMute;
    u32 DSPEnabled;      // 0 -> no, 1 -> yes
    u32 Volume;          // 0-100
};

extern aica_setts aica_settings;
extern aica_init_params aica_params;

void LoadSettingsAica();
void SaveSettingsAica();

int  cfgGetIntAica(const char* key, int def);
void cfgSetIntAica(const char* key, int val);
