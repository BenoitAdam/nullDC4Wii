#include "nullAICA.h"
#include "sgc_if.h"
#include "aica.h"
#include "aica_mem.h"
#include "wii_audiostream.h"

aica_setts aica_settings;
aica_init_params aica_params;
extern emu_info emu;

s32 FASTCALL PluginLoadAica(emu_info* param)
{
    LoadSettingsAica();
    return rv_ok;
}

void FASTCALL PluginUnloadAica()
{
    SaveSettingsAica();
}

s32 FASTCALL InitAica(aica_init_params* initp)
{
    memcpy(&aica_params, initp, sizeof(aica_params));

    init_mem();
    AICA_Init();
    wii_InitAudio();

    return rv_ok;
}

void FASTCALL TermAica()
{
    wii_TermAudio();
    AICA_Term();
    term_mem();
}

void FASTCALL ResetAica(bool Manual)
{
    // nothing needed for now
}

EXPORT void EXPORT_CALL aicaGetInterface(plugin_interface* info)
{
    info->InterfaceVersion = PLUGIN_I_F_VERSION;

#define c info->common
#define a info->aica

    strcpy(c.Name, "nullDC AICA Wii [" __DATE__ "]");

    c.InterfaceVersion = AICA_PLUGIN_I_F_VERSION;
    c.Type             = Plugin_AICA;

    c.Load   = PluginLoadAica;
    c.Unload = PluginUnloadAica;

    a.Init  = InitAica;
    a.Reset = ResetAica;
    a.Term  = TermAica;

    a.Update           = UpdateAICA;
    a.ReadMem_aica_reg  = aica_ReadMem_reg;
    a.WriteMem_aica_reg = aica_WriteMem_reg;

#undef c
#undef a
}

int cfgGetIntAica(const char* key, int def)
{
    return emu.ConfigLoadInt("nullAica", key, def);
}
void cfgSetIntAica(const char* key, int val)
{
    emu.ConfigSaveInt("nullAica", key, val);
}

void LoadSettingsAica()
{
    aica_settings.BufferSize   = 2048;
    aica_settings.LimitFPS     = 0;
    aica_settings.HW_mixing    = 0;
    aica_settings.SoundRenderer= 1;
    aica_settings.GlobalFocus  = 1;
    aica_settings.BufferCount  = 1;
    aica_settings.CDDAMute     = 0;
    aica_settings.GlobalMute   = 0;
    aica_settings.DSPEnabled   = 0;
    aica_settings.Volume       = 90;
}

void SaveSettingsAica()
{
    cfgSetIntAica("BufferSize",    aica_settings.BufferSize);
    cfgSetIntAica("LimitFPS",      aica_settings.LimitFPS);
    cfgSetIntAica("HW_mixing",     aica_settings.HW_mixing);
    cfgSetIntAica("SoundRenderer", aica_settings.SoundRenderer);
    cfgSetIntAica("GlobalFocus",   aica_settings.GlobalFocus);
    cfgSetIntAica("BufferCount",   aica_settings.BufferCount);
    cfgSetIntAica("CDDAMute",      aica_settings.CDDAMute);
    cfgSetIntAica("GlobalMute",    aica_settings.GlobalMute);
    cfgSetIntAica("DSPEnabled",    aica_settings.DSPEnabled);
    cfgSetIntAica("Volume",        max(0, min((int)aica_settings.Volume, 100)));
}
