/*
	Improved block manager header for Dreamcast emulator on Wii - By ClaudeAI
	
	The extern "C" stuff is for assembly code on beagleboard/pandora/wii
*/
#include "types.h"
#pragma once

#if HOST_OS==OS_LINUX || HOST_OS==OS_WII
extern "C" {
#endif

// Block manager configuration
// Kept at 16K buckets like original, but can be tuned for Wii memory constraints
#define BM_BLOCKLIST_COUNT (16384)
#define BM_BLOCKLIST_MASK (BM_BLOCKLIST_COUNT-1)
#define BM_BLOCKLIST_SHIFT 2

// Configuration for Wii platform - adjust based on available memory
#ifndef BM_INITIAL_CAPACITY
#define BM_INITIAL_CAPACITY 16      // Initial blocks per hash bucket
#endif

#ifndef BM_MAX_BLOCKS_PER_BUCKET
#define BM_MAX_BLOCKS_PER_BUCKET 64 // Prevent excessive growth in single bucket
#endif

// Ways in the inline block cache (cache[][]). 2-way set-associative instead of
// direct-mapped: an indirect call/jump/return site that alternates between two
// hot targets (e.g. a vtable call, or a function called from two callers) now
// stays fully cached instead of one target evicting the other every time.
// NOTE: the inlined PPC fast path in wii_driver.cpp hardcodes the bucket
// byte-stride as idx*8 (one doubling of idx*4) assuming exactly 2 ways - if
// this is ever changed, that codegen must be updated to match.
#ifndef BM_CACHE_WAYS
#define BM_CACHE_WAYS 2
#endif

// Enable statistics tracking (disable in release builds for better performance)
// #define BM_ENABLE_STATS

typedef void DynarecCodeEntry();

// Core block manager functions (compatible with original API)
DynarecCodeEntry* FASTCALL bm_GetCode(u32 addr);
void bm_AddCode(u32 addr, DynarecCodeEntry* code);
void bm_Reset();

// Block structure (kept compatible with original for assembly code)
struct DynarecBlock
{
	DynarecCodeEntry* code;
	u32 addr;
	u32 lookups;
	//u32 pad;
};

// Cache array exposed for potential assembly access (like original).
// cache[idx][0] is the MRU way, cache[idx][1] the second-MRU way.
extern DynarecBlock* cache[BM_BLOCKLIST_COUNT][BM_CACHE_WAYS];

// New functions (not in original, but useful for Wii port)
void bm_Init();
bool bm_RemoveCode(u32 addr);
void bm_InvalidateRange(u32 start_addr, u32 end_addr);

// Statistics functions (only available when BM_ENABLE_STATS is defined)
#ifdef BM_ENABLE_STATS
void bm_GetStats(u32* hits, u32* misses, u32* cache_hits, u32* total_blocks);
void bm_ResetStats();
#endif

#if HOST_OS==OS_LINUX || HOST_OS==OS_WII
}
#endif
